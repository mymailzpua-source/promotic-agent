"""Install and operate the local PROMOTIC Runtime bridge."""
import argparse
import json
import math
import os
import tempfile
import time
import uuid
from pathlib import Path
from xml.dom import minidom

from promotic import content, index, named, save_copy, validate

REQUEST = "codex-weight-request.json"
STATUS = "codex-weight-status.json"
DISPLAY = "bridgeWeightDisplay"
RUNTIME_JS = r'''
// Local Codex connection. The test value is used only by MainPanel.
var bridgeLive = weight === null || !isFinite(weight) ? null : weight;
var bridgeText = bridgeLive === null ? "—" : display.Item("weightText").Value + " кг";
var bridgeNow = new Date().getTime();
var bridgeId = null;
var bridgeTest = null;
try {
    var bridgeRaw = Pm.FileTextRead("#data:codex-weight-request.json", 0);
    var bridgeRequest = bridgeRaw ? JSON.parse(String(bridgeRaw)) : null;
    if (bridgeRequest && typeof bridgeRequest.id === "string" &&
        typeof bridgeRequest.until === "number" &&
        bridgeRequest.until > bridgeNow && bridgeRequest.until <= bridgeNow + 600000) {
        if (bridgeRequest.kg === null) {
            bridgeId = bridgeRequest.id;
        } else if (typeof bridgeRequest.kg === "number" && isFinite(bridgeRequest.kg)) {
            bridgeId = bridgeRequest.id;
            bridgeTest = bridgeRequest.kg;
            bridgeText = String(bridgeTest).replace(".", ",") + " кг · ТЕСТ";
        }
    }
} catch (bridgeError) {
    // A missing or unreadable request leaves the normal display active.
}
display.Item("bridgeWeightDisplay").Value = bridgeText;
Pm.FileTextWrite("#data:codex-weight-status.json", JSON.stringify({
    time_ms: bridgeNow, live_kg: bridgeLive, test_kg: bridgeTest,
    request_id: bridgeId, display: bridgeText
}), "charset:utf-8;sep:no;bom:no;");
'''


def replace_script(script, old, new):
    text = content(script)
    if text.count(old) != 1:
        raise ValueError("Скрипт відрізняється від перевіреної версії проєкту")
    script.replaceChild(script.ownerDocument.createCDATASection(text.replace(old, new)), script.firstChild)


def install(source, target):
    doc = minidom.parse(str(source))
    root, = doc.getElementsByTagName("Content")
    objects = dict(index(root))
    timer = objects["/DeltaDisplay"]
    event = named(named(timer, "Events", "PmEvents"), "Event", "onTick")
    script, = event.getElementsByTagName("Script")
    call = 'put("weight", weight === null ? "—" : weight.toFixed(3).replace(".", ","));'
    group = named(objects["/DosingData"], "List", "Vars")
    if named(group, "Props", DISPLAY) is not None:
        raise ValueError("Міст уже налаштовано")
    template = named(group, "Props", "weightText").cloneNode(deep=True)
    template.setAttribute("Name", DISPLAY)
    group.appendChild(template)
    replace_script(script, call, call + "\n" + RUNTIME_JS)
    canvas, = [item for item in objects["/MainPanel"].getElementsByTagName("GItem")
               if item.getAttribute("Name") == "DosingMimic"]
    local = named(named(canvas, "Props", "LocalProps"), "Prop", "weight")
    binding, = local.getElementsByTagName("DBind")
    target_prop = named(binding, "Prop", "Value")
    if content(target_prop) != "/DosingData/#vars/weightText;Value":
        raise ValueError("Прив’язка ваги відрізняється від перевіреної версії")
    target_prop.firstChild.data = f"/DosingData/#vars/{DISPLAY};Value"
    draw = 'words(w==="—"?w:w+" кг",512,392,38,true,ink,"center");'
    canvas_script, = [item for item in canvas.getElementsByTagName("Script") if draw in content(item)]
    replace_script(canvas_script, draw, 'words(w,512,392,38,true,ink,"center");')
    save_copy(doc, target, validate(doc, objects))


def read_status(directory, request_id=None):
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        try:
            status = json.loads((directory / STATUS).read_text(encoding="utf-8-sig"))
            fresh = abs(time.time() * 1000 - status["time_ms"]) < 4500
            if fresh and (request_id is None or status["request_id"] == request_id):
                return status
        except (OSError, ValueError, KeyError, TypeError):
            pass
        time.sleep(0.2)
    raise ValueError("Runtime не підтвердив операцію. Перевірте запуск і шлях до каталогу #data.")


def request(directory, kg, ttl):
    # Place the temporary file on the same volume so replacement is atomic.
    payload = dict(id=uuid.uuid4().hex, until=int(time.time() * 1000) + ttl * 1000, kg=kg)
    with tempfile.NamedTemporaryFile(mode="w", encoding="ascii", dir=directory, delete=False) as temp:
        path = Path(temp.name)
        json.dump(payload, temp, allow_nan=False)
    try:
        deadline = time.monotonic() + 2
        while True:
            try:
                os.replace(path, directory / REQUEST)
                break
            except PermissionError:
                if time.monotonic() >= deadline:
                    raise
                time.sleep(0.05)
    finally:
        path.unlink(missing_ok=True)
    return read_status(directory, payload["id"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="command", required=True)
    setup = subs.add_parser("install")
    setup.add_argument("source", type=Path)
    setup.add_argument("target", type=Path)
    for command in ("status", "set-test-weight", "clear"):
        sub = subs.add_parser(command)
        sub.add_argument("data_directory", type=Path)
        if command == "set-test-weight":
            sub.add_argument("kg", type=float)
            sub.add_argument("--seconds", type=int, default=60)
    args = parser.parse_args()
    if args.command == "install":
        install(args.source, args.target)
        print(args.target)
        return
    directory = args.data_directory
    if args.command == "set-test-weight":
        if not math.isfinite(args.kg) or not 10 <= args.seconds <= 600:
            parser.error("Потрібне скінченне значення ваги й тривалість 10–600 секунд")
        status = request(directory, args.kg, args.seconds)
    elif args.command == "clear":
        status = request(directory, None, 30)
    else:
        status = read_status(directory)
    print(json.dumps(status, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, KeyError) as error:
        raise SystemExit(str(error)) from None
