import argparse
import csv
import json
import math
import posixpath
import re
from pathlib import Path
from xml.dom import DOMException, Node, minidom
from xml.parsers.expat import ExpatError


def children(node, tag):
    return [child for child in node.childNodes if child.nodeType == Node.ELEMENT_NODE and child.tagName == tag]


def named(node, tag, name):
    return next((child for child in children(node, tag) if child.getAttribute("Name") == name), None)


def content(node):
    return "".join(child.data for child in node.childNodes if child.nodeType in (Node.TEXT_NODE, Node.CDATA_SECTION_NODE))


def prop(node, name):
    element = named(node, "Prop", name)
    return content(element) if element is not None else None


def index(node, prefix=""):
    for group in children(node, "PmObjects"):
        for obj in children(group, "PmObject"):
            path = prefix + "/" + obj.getAttribute("Name")
            yield path, obj
            yield from index(obj, path)


def variables(obj):
    group = named(obj, "List", "Vars")
    return children(group, "Props") if group is not None else []


def inspect(objects):
    return [{"path": path, "type": obj.getAttribute("Type"),
             "variables": [{"name": var.getAttribute("Name"), "type": prop(var, "DataType"),
                            "value": prop(var, "Value"), "note": prop(var, "Note"),
                            "unit": prop(var, "Unit")}
                           for var in variables(obj)]}
            for path, obj in objects.items()]


def validate(document, objects):
    findings = []
    refs = {}
    for path, obj in objects.items():
        names = set()
        for var in variables(obj):
            name = var.getAttribute("Name")
            if not name or name in names:
                findings.append(f"{path}: порожня або повторна назва {name!r}")
            names.add(name)
            extensions = named(var, "List", "Extens")
            if extensions is None:
                continue
            for ext in children(extensions, "Props"):
                ext_type = ext.getAttribute("Type")
                target = prop(ext, "PmObject")
                expected = {"Comm": "PmaCommGroup", "Trend": "PmaTrendGroup"}.get(ext_type)
                if expected and target and not target.startswith("$"):
                    address = posixpath.normpath(posixpath.join(path, target))
                    destination = objects.get(address)
                    if destination is None or destination.getAttribute("Type") != expected:
                        findings.append(f"{path}/{name}: {ext_type} → {address}, очікується {expected}")
        refs[path] = names
    for binding in document.getElementsByTagName("DBind"):
        if binding.getAttribute("Type") != "PP":
            continue
        value = prop(binding, "Value") or ""
        match = re.fullmatch(r"(/[^;]*)/#vars/([^;]+);[^;]+", value)
        if match and match[2] not in refs.get(match[1], set()):
            findings.append(f"PP: відсутня змінна {value}")
    return list(dict.fromkeys(findings))


def save_copy(document, destination, findings):
    if findings:
        raise ValueError("Виправте помилки перед збереженням: " + " | ".join(findings))
    data = document.toxml(encoding="UTF-16")
    minidom.parseString(data)
    with destination.open("xb") as output:
        output.write(data)


def change_var(document, objects, args):
    obj = objects.get(args.object)
    if obj is None or obj.getAttribute("Type") != "PmaData":
        raise ValueError("Потрібен шлях до PmaData")
    group = named(obj, "List", "Vars")
    if group is None:
        raise ValueError("У PmaData немає списку Vars")
    var = named(group, "Props", args.name)
    if args.from_var:
        if var is not None or not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", args.name):
            raise ValueError("Нова назва має бути унікальним ідентифікатором")
        template = named(group, "Props", args.from_var)
        if template is None or named(template, "List", "Extens") is not None:
            raise ValueError("Потрібна змінна-зразок без розширень у тому самому об’єкті")
        var = template.cloneNode(deep=True)
        var.setAttribute("Name", args.name)
        group.appendChild(var)
    if var is None:
        raise ValueError("Змінну не знайдено")
    for key in ("Value", "Note", "Unit"):
        value = getattr(args, key.lower())
        if value is None:
            continue
        element = named(var, "Prop", key)
        if element is None:
            element = document.createElement("Prop")
            element.setAttribute("Name", key)
            var.appendChild(element)
        for child in list(element.childNodes):
            element.removeChild(child)
        element.appendChild(document.createTextNode(value))


def check_csv(args):
    invalid = []
    count = 0
    with args.file.open(encoding="utf-8-sig", newline="") as source:
        reader = csv.DictReader(source, delimiter=args.delimiter)
        if args.column not in (reader.fieldnames or []):
            raise ValueError(f"Немає стовпця {args.column!r}")
        for row in reader:
            count += 1
            raw = row[args.column]
            try:
                number = float((raw or "").strip().replace(",", "."))
                if None in row or not math.isfinite(number) or not args.minimum <= number <= args.maximum:
                    raise ValueError
            except ValueError:
                invalid.append({"line": reader.line_num, "value": raw})
    print(json.dumps({"rows": count, "invalid_count": len(invalid), "examples": invalid[:50]}, ensure_ascii=False, indent=2))
    return int(bool(invalid) or count == 0)


def main():
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    for command in ("inspect", "check", "var", "script"):
        sub = commands.add_parser(command)
        sub.add_argument("file", type=Path)
        if command in ("var", "script"):
            sub.add_argument("output", type=Path)
            sub.add_argument("object")
            sub.add_argument("name")
        if command == "var":
            for flag in ("from-var", "value", "note", "unit"):
                sub.add_argument("--" + flag)
        if command == "script":
            sub.add_argument("source", type=Path)
    sub = commands.add_parser("csv")
    sub.add_argument("file", type=Path)
    sub.add_argument("column")
    sub.add_argument("--delimiter", default=";", choices=[";", ",", "\t"])
    sub.add_argument("--minimum", type=float, default=-math.inf)
    sub.add_argument("--maximum", type=float, default=math.inf)
    args = parser.parse_args()
    if args.command == "csv":
        if not args.minimum <= args.maximum:
            raise ValueError("Некоректний діапазон")
        return check_csv(args)
    document = minidom.parse(str(args.file))
    roots = document.getElementsByTagName("Content")
    if len(roots) != 1 or document.documentElement.tagName != "Document":
        raise ValueError("Очікується повний XML-експорт PROMOTIC з одним Content")
    entries = list(index(roots[0]))
    objects = dict(entries)
    if not objects or len(entries) != len(objects):
        raise ValueError("Дерево об’єктів порожнє або має повторні шляхи")
    if args.command == "inspect":
        print(json.dumps(inspect(objects), ensure_ascii=False, indent=2))
        return 0
    if args.command == "check":
        findings = validate(document, objects)
        print(json.dumps({"objects": len(objects), "findings": findings}, ensure_ascii=False, indent=2))
        return int(bool(findings))
    if args.command == "var":
        change_var(document, objects, args)
    else:
        obj = objects.get(args.object)
        events = children(obj, "Events") if obj is not None else []
        matches = [script for group in events for event in children(group, "Event")
                   if event.getAttribute("Name") == args.name for script in children(event, "Script")]
        if len(matches) != 1:
            raise ValueError("Потрібна одна наявна подія з блоком Script")
        script = matches[0]
        source = args.source.read_text(encoding="utf-8-sig")
        for child in list(script.childNodes):
            script.removeChild(child)
        script.appendChild(document.createCDATASection(source))
    save_copy(document, args.output, validate(document, objects))
    print(args.output)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, DOMException, ExpatError) as error:
        raise SystemExit(str(error)) from None
